# АвтоСервис — Android prototype

## Build APK on GitHub
1. Upload the contents of this archive to the root of your GitHub repository (not the ZIP file itself).
2. Keep the `.github/workflows/android.yml` path exactly as shown.
3. Open the Actions tab and select **Build Android APK**.
4. Wait for the green check, open the run, and download the `AvtoServis-debug-apk` artifact.
5. Extract the artifact ZIP to get `app-debug.apk`.

## Important
This is an early Android WebView prototype. It stores demo data locally on one device.
It does not yet include a server, shared database, real accounts, or enforced employee roles.
Do not use it as the sole production record system. Those parts are the next development stage.
